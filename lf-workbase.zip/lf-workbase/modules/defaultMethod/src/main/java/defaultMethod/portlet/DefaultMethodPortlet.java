package defaultMethod.portlet;

import com.liferay.document.library.kernel.model.DLFileEntry;
import com.liferay.document.library.kernel.model.DLFolder;
import com.liferay.document.library.kernel.model.DLFolderConstants;
import com.liferay.document.library.kernel.service.DLAppLocalServiceUtil;
import com.liferay.document.library.kernel.service.DLFolderServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.ResourceConstants;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.Theme;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.security.permission.ActionKeys;
import com.liferay.portal.kernel.service.ResourcePermissionLocalServiceUtil;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.service.UserServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.upload.FileItem;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.File;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.LocaleUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.WebKeys;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import defaultMethod.constants.DefaultMethodPortletKeys;

/**
 * @author Avan
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=DefaultMethod", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + DefaultMethodPortletKeys.DEFAULTMETHOD,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class DefaultMethodPortlet extends MVCPortlet {

	private static Log logger = LogFactoryUtil.getLog(Logger.class);

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		// TODO Auto-generated method stub
		System.out.println("Default Method Render Called");
		List<User> user = UserLocalServiceUtil.getUsers(-1, -1);

		System.out.println("Users Count: " + user.size());
		/*
		 * for (User user2 : user) {
		 * System.out.println("User Name: "+user2.getFullName()); }
		 */
		


		ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		Theme themeName = themeDisplay.getTheme();
		System.out.println(themeName.getName());

		System.out.println(themeDisplay.getCompanyLogo());

		System.out.println(themeDisplay.getUser().getFullName());
		
		/*
		 * try { UserLocalServiceUtil.addUser(0, PortalUtil.getDefaultCompanyId(),
		 * false, "test1", "test1", true, "", "a@gmail.com", LocaleUtil.getDefault(),
		 * "A", "R", "I", 0l, 0l, true, 01, 01, 1970, "", new long[] {20121}, new
		 * long[0], new long[0], new long[0], false, null); } catch (PortalException e)
		 * { // TODO Auto-generated catch block e.printStackTrace(); }
		 */

		super.render(renderRequest, renderResponse);
	}

	@ProcessAction(name = "addImage")
	public String fileUpload(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException {
		long accessoryVariantId = 1;
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		logger.info("Start::: Class :: AccessoryPortlet, Method Name:: fileUpload");
		
		
		
		UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);

		/*
		 * long companyId = themeDisplay.getCompanyId(); Role pmtcuser =
		 * RoleLocalServiceUtil.getRole(companyId, "PMTC User");
		 */
		String fileEntryLst = "";

		Map<String, FileItem[]> files = uploadPortletRequest.getMultipartParameterMap();
		long mrfFolderId = DLFolderServiceUtil.getFolder(GetterUtil.getLong(themeDisplay.getScopeGroupId()),
				DLFolderConstants.DEFAULT_PARENT_FOLDER_ID, "Product_Images").getFolderId();
		ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFileEntry.class.getName(), actionRequest);
		long accessoryFolderId = 0;
		try {
			accessoryFolderId = DLFolderServiceUtil
					.getFolder(GetterUtil.getLong(themeDisplay.getScopeGroupId()), mrfFolderId, "Accessory")
					.getFolderId();

		} catch (PortalException e1) {

			logger.error("EXCEPTION in fileUpload method , Class :: AccessoryPortlet");
			logger.error(e1);

			Folder accessoryFolder = null;
			try {
				accessoryFolder = DLAppLocalServiceUtil.addFolder(GetterUtil.getLong(themeDisplay.getUserId()),
						GetterUtil.getLong(themeDisplay.getScopeGroupId()), mrfFolderId, "Accessory",
						"Accessory Folder", serviceContext);
			} catch (PortalException e) {
				logger.error("EXCEPTION in fileUpload method , Class :: AccessoryPortlet");
				logger.error(e);
			}
			accessoryFolderId = accessoryFolder.getFolderId();

		}

		try {
			DLFolderServiceUtil.getFolder(GetterUtil.getLong(themeDisplay.getScopeGroupId()), accessoryFolderId,
					accessoryVariantId + "").getFolderId();
		} catch (PortalException e1) {

			logger.error("EXCEPTION in fileUpload method , Class :: AccessoryPortlet");
			logger.error(e1);

			Folder accessoryVariantFolder = null;
			try {
				accessoryVariantFolder = DLAppLocalServiceUtil.addFolder(GetterUtil.getLong(themeDisplay.getUserId()),
						GetterUtil.getLong(themeDisplay.getScopeGroupId()), accessoryFolderId, accessoryVariantId + "",
						accessoryVariantId + "Accessory Folder", serviceContext);
			} catch (PortalException e) {
				logger.error("EXCEPTION in fileUpload method , Class :: AccessoryPortlet");
				logger.error(e);
			}
			accessoryVariantFolder.getFolderId();
		}

		/*
		 * ResourcePermissionLocalServiceUtil.setResourcePermissions(companyId,
		 * DLFolder.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
		 * accessoryFolderId+"", pmtcuser.getRoleId(), new String[] { ActionKeys.VIEW
		 * });
		 */

		java.io.File file;
		String title, description;
		for (Entry<String, FileItem[]> file2 : files.entrySet()) {
			System.out.println("-555---" + file2.getKey());
			FileItem item[] = file2.getValue();

			try {

				for (FileItem fileItem : item) {
					title = fileItem.getFileName();
					// System.out.println("fileItem.getFileName()--------" +fileItem.getFileName());
					if (!title.equals("")) {
						description = title + " is added via programatically";

						file = fileItem.getStoreLocation();

						try {

							FileEntry fileEntry = DLAppLocalServiceUtil.addFileEntry(themeDisplay.getUserId(),
									DLFolderServiceUtil.getFolder(GetterUtil.getLong(themeDisplay.getScopeGroupId()),
											accessoryFolderId, accessoryVariantId + "").getRepositoryId(),
									DLFolderServiceUtil.getFolder(GetterUtil.getLong(themeDisplay.getScopeGroupId()),
											accessoryFolderId, accessoryVariantId + "").getFolderId(),
									fileItem.getFileName(), fileItem.getContentType(), title, description, "", file,
									serviceContext);

							/*
							 * ResourcePermissionLocalServiceUtil.setResourcePermissions(companyId,
							 * DLFileEntry.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
							 * fileEntry.getFileEntryId()+"", pmtcuser.getRoleId(), new String[] {
							 * ActionKeys.VIEW });
							 */

							fileEntryLst = fileEntryLst + fileEntry.getFileEntryId() + "::";
							System.out.println("fileEntryLst------" + fileEntryLst);
						} catch (PortalException e) {
							logger.error("PortalException in fileUpload method , Class :: AccessoryPortlet");
							logger.error(e);
						} catch (SystemException e) {
							logger.error("SystemException in fileUpload method , Class :: AccessoryPortlet");
							logger.error(e);
						}
					}
				}
			} catch (Exception e) {
				logger.error("EXCEPTION in fileUpload method , Class :: AccessoryPortlet");
				logger.error(e);
			}
		}

		logger.info("Start::: Class :: AccessoryPortlet, Method Name:: fileUpload");
		return fileEntryLst;
	}
}