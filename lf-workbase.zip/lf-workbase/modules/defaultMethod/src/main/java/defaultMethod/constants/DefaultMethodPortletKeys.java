package defaultMethod.constants;

/**
 * @author Avan
 */
public class DefaultMethodPortletKeys {

	public static final String DEFAULTMETHOD =
		"defaultMethod_DefaultMethodPortlet";

}