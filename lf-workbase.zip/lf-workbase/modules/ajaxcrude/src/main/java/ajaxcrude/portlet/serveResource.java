package ajaxcrude.portlet;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;
import java.util.List;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import ajaxcrude.constants.AjaxcrudePortletKeys;
import student.model.Student;
import student.model.Todo;
import student.model.impl.TodoImpl;
import student.service.StudentLocalServiceUtil;
import student.service.TodoLocalService;
import student.service.TodoLocalServiceUtil;
import student.service.TodoService;
import student.service.TodoServiceUtil;
import student.service.base.TodoServiceBaseImpl;
import student.service.persistence.TodoUtil;

@Component(immediate = true, property = {

		"javax.portlet.name=" + AjaxcrudePortletKeys.AJAXCRUDE, "mvc.command.name=callmethod"

}, service = MVCResourceCommand.class)
public class serveResource implements MVCResourceCommand {

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws PortletException {
		String method = ParamUtil.getString(resourceRequest, "method");

		System.out.println(method);

		System.out.println("call serve resource ");

		if (method.equals("getAlltodo")) {
			try {
				getAllTodo(resourceRequest, resourceResponse);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (method.equals("addTodo")) {
		try {
			addTodo(resourceRequest, resourceResponse);
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		if (method.equals("delettodo")) {
			try {
				deleteTodo(resourceRequest, resourceResponse);
		
			} catch (PortalException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return true;
	}

	private void getAllTodo(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
				
		
		System.out.println("getall word");

		List<Todo> todo = todoservice.getAllTodo(0,todoservice.getCount());
		JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
		for (Todo data : todo) {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			jsonObject.put("todoid", data.getTodoid());
			jsonObject.put("title", data.getTitle());
			jsonObject.put("discription", data.getDiscription());
			jsonArray.put(jsonObject);
		}
		resourceResponse.getWriter().print(jsonArray.toJSONString());



	}
	
	private void deleteTodo(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException, PortalException {

		String id = ParamUtil.getString(resourceRequest, "id");


		System.out.println("delet method called");
		System.out.println(id);

		todoservice.deletTodoByid(Long.parseLong(id));
		

	}
	
	private void addTodo(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException, PortalException {

		String title = ParamUtil.getString(resourceRequest, "title1");
		String discription = ParamUtil.getString(resourceRequest, "discription1");
		long id = ParamUtil.getLong(resourceRequest, "id");


		System.out.println("add method called");
		System.out.println(id+title+discription);


		todoservice.addTodo(id, title, discription);
		

	}
	
	@Reference
	TodoService todoservice;
}