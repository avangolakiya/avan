package ajaxcrude.constants;

/**
 * @author Avan
 */
public class AjaxcrudePortletKeys {

	public static final String AJAXCRUDE =
		"ajaxcrude_AjaxcrudePortlet";

}