package miantask.portlet;

import miantask.constants.MiantaskPortletKeys;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.jdbc.OutputBlob;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.LocaleUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.ProcessAction;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import mainbuilder.model.Users;
import mainbuilder.service.UsersLocalServiceUtil;
import mainbuilder.service.UsersService;

/**
 * @author Avan
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Miantask", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp", "javax.portlet.name=" + MiantaskPortletKeys.MIANTASK,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class MiantaskPortlet extends MVCPortlet {
	private static Log _log = LogFactoryUtil.getLog(Logger.class);

	@ProcessAction(name = "updateuser")
	public void updateuser(ActionRequest actionRequest, ActionResponse actionResponse)
			throws NumberFormatException, PortalException, IOException {
		String id = ParamUtil.getString(actionRequest, "id");
		String firstName = ParamUtil.getString(actionRequest, "firstname");
		String lastName = ParamUtil.getString(actionRequest, "lastname");
		String gender = ParamUtil.getString(actionRequest, "gender");

		String hobbieArray[] = ParamUtil.getStringValues(actionRequest, "hobbie");
		String hobbie = "";

		if (Validator.isNotNull(hobbieArray)) {
			for (String element : hobbieArray) {
				hobbie += element + ",";
			}
		}

		String email = ParamUtil.getString(actionRequest, "email");

		String age = ParamUtil.getString(actionRequest, "age");

		Date dob = ParamUtil.getDate(actionRequest, "dob", new SimpleDateFormat("yyyy-mm-dd"));

		String address = ParamUtil.getString(actionRequest, "address");

		UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(actionRequest);
		File photoImage = uploadRequest.getFile("imageupload");

		Users user = UsersLocalServiceUtil.getUsers(Long.parseLong(id));
		if (photoImage.exists()) {
			byte[] imageData = new byte[(int) photoImage.length()];
			FileInputStream fileInputStream = new FileInputStream(photoImage);
			fileInputStream.read(imageData);

			// Encode the byte array into a Base64 string
			String base64String = Base64.getEncoder().encodeToString(imageData);
			user.setImagename(base64String);

		}
		user.setFirstname(firstName);
		user.setLastname(lastName);
		user.setAddress(address);
		user.setAge(age);
		user.setDob(dob);
		user.setHobbie(hobbie);
		user.setEmail(email);
		user.setGender(gender);

		UsersLocalServiceUtil.updateUsers(user);
	}

	@ProcessAction(name = "insertUser")
	public void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		String firstName = ParamUtil.getString(actionRequest, "firstname");
		String lastName = ParamUtil.getString(actionRequest, "lastname");
		String email = ParamUtil.getString(actionRequest, "email");
		String mobileno = ParamUtil.getString(actionRequest, "mobileno");
		Date dob = ParamUtil.getDate(actionRequest, "dob", new SimpleDateFormat("yyyy-mm-dd"));
		String gender = ParamUtil.getString(actionRequest, "gender");

		String hobbieArray[] = ParamUtil.getStringValues(actionRequest, "hobbie");
		String hobbie = "";

		if (Validator.isNotNull(hobbieArray)) {
			for (String element : hobbieArray) {
				hobbie += element + ",";
			}
		}

		String age = ParamUtil.getString(actionRequest, "age");
		String password = ParamUtil.getString(actionRequest, "password");
		String address = ParamUtil.getString(actionRequest, "address");

		UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(actionRequest);
		File photoImage = uploadRequest.getFile("imageupload");
		InputStream fis = new FileInputStream(photoImage);
		OutputBlob dataOutputBlob = new OutputBlob(fis, photoImage.length());

		byte[] imageData = new byte[(int) photoImage.length()];
		FileInputStream fileInputStream = new FileInputStream(photoImage);
		fileInputStream.read(imageData);

		// Encode the byte array into a Base64 string
		String base64String = Base64.getEncoder().encodeToString(imageData);

		_log.info(firstName + " " + lastName + " " + email + " " + mobileno + " " + dob + " " + gender + " " + hobbie
				+ " " + age + " " + password + " " + address + " ");

		Users user = UsersLocalServiceUtil.createUsers(CounterLocalServiceUtil.increment());
		user.setFirstname(firstName);
		user.setLastname(lastName);
		user.setEmail(email);
		user.setMobileno(mobileno);
		user.setDob(dob);
		user.setGender(gender);
		user.setHobbie(hobbie);
		user.setAge(age);
		user.setPassword(password);
		user.setAddress(address);
		user.setImageupload(dataOutputBlob);
		user.setImagename(base64String);

		_log.info(photoImage);

		UsersLocalServiceUtil.addUsers(user);
		

		try {
			UserLocalServiceUtil.addUser(0, PortalUtil.getDefaultCompanyId(), false, password, password, true, "",
					email, LocaleUtil.getDefault(), firstName, " ", lastName, 0l, 0l, true, 01, 01, 1970, "",
					new long[] { 20121 }, new long[0], new long[0], new long[0], false, null);
			
		}

		catch (PortalException e) {
			_log.error(e);
		}
	
		 

	}

	@Reference
	UsersService userservice;
}