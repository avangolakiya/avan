package miantask.constants;

/**
 * @author Avan
 */
public class MiantaskPortletKeys {

	public static final String MIANTASK =
		"miantask_MiantaskPortlet";

}