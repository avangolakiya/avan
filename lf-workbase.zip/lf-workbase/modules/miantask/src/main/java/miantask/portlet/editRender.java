package miantask.portlet;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import java.util.List;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import mainbuilder.model.Users;
import mainbuilder.service.UsersLocalServiceUtil;
import miantask.constants.MiantaskPortletKeys;


@Component(
		immediate = true,
		property= {
				
				"javax.portlet.name=" + MiantaskPortletKeys.MIANTASK,
				"mvc.command.name=edituser"
				
		}
		
		)
public class editRender implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		System.out.println("edit render");
		String id = ParamUtil.getString(renderRequest, "id");
		
		System.out.println(id);
		
		try {
			Users data =  UsersLocalServiceUtil.getUsers(Long.parseLong(id));
			renderRequest.setAttribute("i", data);
		} catch (NumberFormatException | PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "/edit.jsp";
	}

}
