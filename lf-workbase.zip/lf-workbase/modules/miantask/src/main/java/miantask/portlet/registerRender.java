package miantask.portlet;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import miantask.constants.MiantaskPortletKeys;

@Component(
		immediate = true,
		property= {
				
				"javax.portlet.name=" + MiantaskPortletKeys.MIANTASK,
				"mvc.command.name=registerPage"
				
		}
		
		)
public class registerRender implements MVCRenderCommand{

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		// TODO Auto-generated method stub
		return "/register.jsp";
	}

}
