package miantask.portlet;

import com.liferay.headless.form.dto.v1_0.Validation;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCResourceCommand;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.Validator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import mainbuilder.model.Users;
import mainbuilder.service.UsersLocalServiceUtil;
import mainbuilder.service.UsersService;
import miantask.constants.MiantaskPortletKeys;


@Component(immediate = true, property = {

		"javax.portlet.name=" + MiantaskPortletKeys.MIANTASK,
		"mvc.command.name=callmethod"

}, service = MVCResourceCommand.class)
public class serveResource implements MVCResourceCommand {
	
	private static Log _log = LogFactoryUtil.getLog(Logger.class);

	@Override
	public boolean serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws PortletException {
		String method = ParamUtil.getString(resourceRequest, "method");

		_log.info(method);

		_log.info("call serve resource ");

		if (method.equals("getAlluser")) {
			try {
				getAllTodo(resourceRequest, resourceResponse);
			} catch (IOException e) {
				_log.error(e);
			}
		}
		
		if (method.equals("deletuser")) {
			try {
				deleteTodo(resourceRequest, resourceResponse);
		
			} catch (PortalException e) {
				_log.error(e);
			} catch (IOException e) {
				_log.error(e);

			}
		}

		if (method.equals("checkEmailDuplicate")) {
		
				try {
					emailDuplicateCheck(resourceRequest, resourceResponse);
				} catch (IOException e) {
					_log.error(e);
				}
			
		}

		return true;
	}

	

	private void emailDuplicateCheck(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException {
		String email=ParamUtil.getString(resourceRequest, "email");
		_log.info(email);
    	List<Users> findemail =  userservice.findByEmail(email);
    	
    	if(!findemail.isEmpty()) {
    		
    		JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			jsonObject.put("email", findemail.get(0).getEmail());
			jsonArray.put(jsonObject);
			resourceResponse.getWriter().print(jsonArray.toJSONString());

    	}
    	else {

    		JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			jsonObject.put("email", "");
			jsonArray.put(jsonObject);
			resourceResponse.getWriter().print(jsonArray.toJSONString());
    	}
		
	}



	private void getAllTodo(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
				
			List<Users>  users = UsersLocalServiceUtil.getUserses(0, UsersLocalServiceUtil.getUsersesCount());
		JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
		for (Users data : users) {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			jsonObject.put("id", data.getId());
			jsonObject.put("firstname", data.getFirstname());
			jsonObject.put("lastname", data.getLastname());
			jsonObject.put("email", data.getEmail());
			jsonObject.put("gender", data.getGender());
			jsonObject.put("hobbie", data.getHobbie());
			jsonObject.put("age", data.getAge());
			jsonObject.put("dob", data.getDob());
			jsonObject.put("mobileno", data.getMobileno());
			jsonObject.put("address", data.getAddress());
			jsonObject.put("image", data.getImagename());
			jsonObject.put("imageupload", data.getImageupload());
			jsonArray.put(jsonObject);
		}
		resourceResponse.getWriter().print(jsonArray.toJSONString());

	}
	
	private void deleteTodo(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException, PortalException {

		String id = ParamUtil.getString(resourceRequest, "id");

		_log.info("delet method called");
		_log.info(id);
		
		UsersLocalServiceUtil.deleteUsers(Long.parseLong(id));

	}	

	@Reference
	UsersService userservice;

}