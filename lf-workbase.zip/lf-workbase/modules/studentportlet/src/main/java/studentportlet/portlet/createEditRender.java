package studentportlet.portlet;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import  org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import student.service.StudentService;
import studentportlet.constants.StudentportletPortletKeys;



@Component(
		immediate = true,
		property= {
				
				"javax.portlet.name=" +StudentportletPortletKeys.STUDENTPORTLET,
				"mvc.command.name=/create/edit"
				
		}
		
		)
public class createEditRender implements MVCRenderCommand {

	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {

		long studentid = ParamUtil.getLong(renderRequest, "studentid", 0);
		
		System.out.println(studentid);
		
		if(studentid>0)
		{
			try {
				renderRequest.setAttribute("studentdata", _studentService.getStudentByid(studentid));
			} catch (PortalException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
		return "/edit.jsp";
	}
	
private StudentService _studentService;
	
	@Reference(unbind = "-")
	protected void setEmployeeService(StudentService studentService) {
	    _studentService = studentService;
	}

}
