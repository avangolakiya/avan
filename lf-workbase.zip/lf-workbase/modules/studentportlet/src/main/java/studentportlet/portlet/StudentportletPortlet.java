package studentportlet.portlet;

import studentportlet.constants.StudentportletPortletKeys;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;
import java.util.List;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.ProcessEvent;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.annotations.ActionMethod;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import student.model.Student;
import student.service.StudentService;

/**
 * @author Avan
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Studentportlet", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + StudentportletPortletKeys.STUDENTPORTLET,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class StudentportletPortlet extends MVCPortlet {

	@Override
	public void doView(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {

		int delta = ParamUtil.getInteger(renderRequest, "delta");
		int cur = ParamUtil.getInteger(renderRequest, "cur");
		int from = delta * (cur - 1);
		int to = delta == 0 ? 10 : delta * cur;

		renderRequest.setAttribute("totalStudent", _studentService.getCount());

		renderRequest.setAttribute("studentdata", _studentService.getAllStudent(from, to));

		super.doView(renderRequest, renderResponse);

		System.out.println("hello word");
	}

	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {

		String method = ParamUtil.getString(resourceRequest, "method");
		System.out.println(method);
		System.out.println("serve resource");


		if (method == "deleteMethod");
		{
			deleteStudent(resourceRequest, resourceResponse);
		}

		if (method == "getAllData");
		{
			getstudentdata(resourceRequest, resourceResponse);

		}

		super.serveResource(resourceRequest, resourceResponse);
	}

	private void getstudentdata(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {

		System.out.println("getall word");
		System.out.println(_studentService.getAllStudent(1, _studentService.getCount()));

		List<Student> students = _studentService.getAllStudent(0, _studentService.getCount());
		JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
		for (Student data : students) {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			jsonObject.put("studentid", data.getStudentid());
			jsonObject.put("name", data.getName());
			jsonObject.put("rollno", data.getRollno());
			jsonObject.put("subject", data.getSubject());
			jsonArray.put(jsonObject);
		}
		resourceResponse.getWriter().print(jsonArray.toJSONString());

	}

	private void deleteStudent(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {

		long studentid = ParamUtil.get(resourceRequest, "studentid", 0);
		System.out.println(studentid);

		System.out.println("delet method called");

		// _studentService.deleteStudent(studentid);

		// studentlocalserviceutill.deleteStudent(studentid);

		try {
			_studentService.deletStudentByid(studentid);
		} catch (PortalException e) {
			e.printStackTrace();
		}

	}

	@Reference
	private StudentService _studentService;

}