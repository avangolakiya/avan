package studentportlet.constants;

/**
 * @author Avan
 */
public class StudentportletPortletKeys {

	public static final String STUDENTPORTLET =
		"studentportlet_StudentportletPortlet";

}