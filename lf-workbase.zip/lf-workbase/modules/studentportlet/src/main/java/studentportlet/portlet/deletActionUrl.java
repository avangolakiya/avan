package studentportlet.portlet;

import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import student.service.StudentLocalServiceUtil;
import student.service.StudentService;
import student.service.persistence.StudentUtil;
import studentportlet.constants.StudentportletPortletKeys;


@Component(immediate = true,
property = {
		
		"javax.portlet.name=" +StudentportletPortletKeys.STUDENTPORTLET,
		"mvc.command.name=deletActionUrl"
},
service = MVCActionCommand.class
)
public class deletActionUrl extends BaseMVCActionCommand{

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		long studentid=ParamUtil.get(actionRequest, "studentid",0);
		
		System.out.println("delet method called");

		//_studentService.deleteStudent(studentid);
		
		//studentlocalserviceutill.deleteStudent(studentid);
		
		studentlocalserviceutill.deletStudentByid(studentid);
		
	}
	
	
	@Reference
	private StudentService studentlocalserviceutill;
	


}
