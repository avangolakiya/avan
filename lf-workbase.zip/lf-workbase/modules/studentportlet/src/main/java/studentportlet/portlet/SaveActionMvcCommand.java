package studentportlet.portlet;

import com.liferay.portal.kernel.portlet.bridges.mvc.BaseMVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import studentportlet.constants.StudentportletPortletKeys;

import student.service.StudentService;


@Component(immediate = true,
		property = {
				
				"javax.portlet.name=" +StudentportletPortletKeys.STUDENTPORTLET,
				"mvc.command.name=savestudent"
		},
		service = MVCActionCommand.class
		)
public class SaveActionMvcCommand extends BaseMVCActionCommand{
	

	@Override
	protected void doProcessAction(ActionRequest actionRequest, ActionResponse actionResponse) throws Exception {

		System.out.println("save method called");
		
//		String name=ParamUtil.get(actionRequest, "name", "");
//		String rollno=ParamUtil.get(actionRequest, "rollno", "");
//
//		String subject=ParamUtil.get(actionRequest, "subject", "");
//		
		long studentid=ParamUtil.get(actionRequest, "studentid",0);

		
		String name=ParamUtil.getString(actionRequest, "name");
		String rollno=ParamUtil.getString(actionRequest, "rollno");

		String subject=ParamUtil.getString(actionRequest, "subject");
		
		
		System.out.println("hellooooooooooo");

		System.out.println(name+rollno+subject);
		

		_studentService.addStudent(studentid,name,rollno,subject);
	
	}
	
	private StudentService _studentService;
	
	@Reference(unbind = "-")
	protected void setEmployeeService(StudentService studentService) {
	    _studentService = studentService;
	}


}
