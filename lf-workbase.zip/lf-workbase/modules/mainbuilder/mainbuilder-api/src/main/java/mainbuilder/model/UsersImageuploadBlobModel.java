/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package mainbuilder.model;

import java.sql.Blob;

/**
 * The Blob model class for lazy loading the imageupload column in Users.
 *
 * @author Brian Wing Shun Chan
 * @see Users
 * @generated
 */
public class UsersImageuploadBlobModel {

	public UsersImageuploadBlobModel() {
	}

	public UsersImageuploadBlobModel(long id) {
		_id = id;
	}

	public UsersImageuploadBlobModel(long id, Blob imageuploadBlob) {
		_id = id;
		_imageuploadBlob = imageuploadBlob;
	}

	public long getId() {
		return _id;
	}

	public void setId(long id) {
		_id = id;
	}

	public Blob getImageuploadBlob() {
		return _imageuploadBlob;
	}

	public void setImageuploadBlob(Blob imageuploadBlob) {
		_imageuploadBlob = imageuploadBlob;
	}

	private long _id;
	private Blob _imageuploadBlob;

}