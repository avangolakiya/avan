/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package mainbuilder.model;

import java.io.Serializable;

import java.sql.Blob;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link mainbuilder.service.http.UsersServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @deprecated As of Athanasius (7.3.x), with no direct replacement
 * @generated
 */
@Deprecated
public class UsersSoap implements Serializable {

	public static UsersSoap toSoapModel(Users model) {
		UsersSoap soapModel = new UsersSoap();

		soapModel.setUuid(model.getUuid());
		soapModel.setId(model.getId());
		soapModel.setFirstname(model.getFirstname());
		soapModel.setLastname(model.getLastname());
		soapModel.setEmail(model.getEmail());
		soapModel.setMobileno(model.getMobileno());
		soapModel.setDob(model.getDob());
		soapModel.setGender(model.getGender());
		soapModel.setHobbie(model.getHobbie());
		soapModel.setAge(model.getAge());
		soapModel.setImagename(model.getImagename());
		soapModel.setImageupload(model.getImageupload());
		soapModel.setPassword(model.getPassword());
		soapModel.setAddress(model.getAddress());

		return soapModel;
	}

	public static UsersSoap[] toSoapModels(Users[] models) {
		UsersSoap[] soapModels = new UsersSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static UsersSoap[][] toSoapModels(Users[][] models) {
		UsersSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new UsersSoap[models.length][models[0].length];
		}
		else {
			soapModels = new UsersSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static UsersSoap[] toSoapModels(List<Users> models) {
		List<UsersSoap> soapModels = new ArrayList<UsersSoap>(models.size());

		for (Users model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new UsersSoap[soapModels.size()]);
	}

	public UsersSoap() {
	}

	public long getPrimaryKey() {
		return _id;
	}

	public void setPrimaryKey(long pk) {
		setId(pk);
	}

	public String getUuid() {
		return _uuid;
	}

	public void setUuid(String uuid) {
		_uuid = uuid;
	}

	public long getId() {
		return _id;
	}

	public void setId(long id) {
		_id = id;
	}

	public String getFirstname() {
		return _firstname;
	}

	public void setFirstname(String firstname) {
		_firstname = firstname;
	}

	public String getLastname() {
		return _lastname;
	}

	public void setLastname(String lastname) {
		_lastname = lastname;
	}

	public String getEmail() {
		return _email;
	}

	public void setEmail(String email) {
		_email = email;
	}

	public String getMobileno() {
		return _mobileno;
	}

	public void setMobileno(String mobileno) {
		_mobileno = mobileno;
	}

	public Date getDob() {
		return _dob;
	}

	public void setDob(Date dob) {
		_dob = dob;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	public String getHobbie() {
		return _hobbie;
	}

	public void setHobbie(String hobbie) {
		_hobbie = hobbie;
	}

	public String getAge() {
		return _age;
	}

	public void setAge(String age) {
		_age = age;
	}

	public String getImagename() {
		return _imagename;
	}

	public void setImagename(String imagename) {
		_imagename = imagename;
	}

	public Blob getImageupload() {
		return _imageupload;
	}

	public void setImageupload(Blob imageupload) {
		_imageupload = imageupload;
	}

	public String getPassword() {
		return _password;
	}

	public void setPassword(String password) {
		_password = password;
	}

	public String getAddress() {
		return _address;
	}

	public void setAddress(String address) {
		_address = address;
	}

	private String _uuid;
	private long _id;
	private String _firstname;
	private String _lastname;
	private String _email;
	private String _mobileno;
	private Date _dob;
	private String _gender;
	private String _hobbie;
	private String _age;
	private String _imagename;
	private Blob _imageupload;
	private String _password;
	private String _address;

}