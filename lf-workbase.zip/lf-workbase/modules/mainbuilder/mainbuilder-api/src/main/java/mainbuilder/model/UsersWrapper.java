/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package mainbuilder.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.sql.Blob;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Users}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see Users
 * @generated
 */
public class UsersWrapper
	extends BaseModelWrapper<Users> implements ModelWrapper<Users>, Users {

	public UsersWrapper(Users users) {
		super(users);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("id", getId());
		attributes.put("firstname", getFirstname());
		attributes.put("lastname", getLastname());
		attributes.put("email", getEmail());
		attributes.put("mobileno", getMobileno());
		attributes.put("dob", getDob());
		attributes.put("gender", getGender());
		attributes.put("hobbie", getHobbie());
		attributes.put("age", getAge());
		attributes.put("imagename", getImagename());
		attributes.put("imageupload", getImageupload());
		attributes.put("password", getPassword());
		attributes.put("address", getAddress());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long id = (Long)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String firstname = (String)attributes.get("firstname");

		if (firstname != null) {
			setFirstname(firstname);
		}

		String lastname = (String)attributes.get("lastname");

		if (lastname != null) {
			setLastname(lastname);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String mobileno = (String)attributes.get("mobileno");

		if (mobileno != null) {
			setMobileno(mobileno);
		}

		Date dob = (Date)attributes.get("dob");

		if (dob != null) {
			setDob(dob);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String hobbie = (String)attributes.get("hobbie");

		if (hobbie != null) {
			setHobbie(hobbie);
		}

		String age = (String)attributes.get("age");

		if (age != null) {
			setAge(age);
		}

		String imagename = (String)attributes.get("imagename");

		if (imagename != null) {
			setImagename(imagename);
		}

		Blob imageupload = (Blob)attributes.get("imageupload");

		if (imageupload != null) {
			setImageupload(imageupload);
		}

		String password = (String)attributes.get("password");

		if (password != null) {
			setPassword(password);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}
	}

	/**
	 * Returns the address of this users.
	 *
	 * @return the address of this users
	 */
	@Override
	public String getAddress() {
		return model.getAddress();
	}

	/**
	 * Returns the age of this users.
	 *
	 * @return the age of this users
	 */
	@Override
	public String getAge() {
		return model.getAge();
	}

	/**
	 * Returns the dob of this users.
	 *
	 * @return the dob of this users
	 */
	@Override
	public Date getDob() {
		return model.getDob();
	}

	/**
	 * Returns the email of this users.
	 *
	 * @return the email of this users
	 */
	@Override
	public String getEmail() {
		return model.getEmail();
	}

	/**
	 * Returns the firstname of this users.
	 *
	 * @return the firstname of this users
	 */
	@Override
	public String getFirstname() {
		return model.getFirstname();
	}

	/**
	 * Returns the gender of this users.
	 *
	 * @return the gender of this users
	 */
	@Override
	public String getGender() {
		return model.getGender();
	}

	/**
	 * Returns the hobbie of this users.
	 *
	 * @return the hobbie of this users
	 */
	@Override
	public String getHobbie() {
		return model.getHobbie();
	}

	/**
	 * Returns the ID of this users.
	 *
	 * @return the ID of this users
	 */
	@Override
	public long getId() {
		return model.getId();
	}

	/**
	 * Returns the imagename of this users.
	 *
	 * @return the imagename of this users
	 */
	@Override
	public String getImagename() {
		return model.getImagename();
	}

	/**
	 * Returns the imageupload of this users.
	 *
	 * @return the imageupload of this users
	 */
	@Override
	public Blob getImageupload() {
		return model.getImageupload();
	}

	/**
	 * Returns the lastname of this users.
	 *
	 * @return the lastname of this users
	 */
	@Override
	public String getLastname() {
		return model.getLastname();
	}

	/**
	 * Returns the mobileno of this users.
	 *
	 * @return the mobileno of this users
	 */
	@Override
	public String getMobileno() {
		return model.getMobileno();
	}

	/**
	 * Returns the password of this users.
	 *
	 * @return the password of this users
	 */
	@Override
	public String getPassword() {
		return model.getPassword();
	}

	/**
	 * Returns the primary key of this users.
	 *
	 * @return the primary key of this users
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the uuid of this users.
	 *
	 * @return the uuid of this users
	 */
	@Override
	public String getUuid() {
		return model.getUuid();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the address of this users.
	 *
	 * @param address the address of this users
	 */
	@Override
	public void setAddress(String address) {
		model.setAddress(address);
	}

	/**
	 * Sets the age of this users.
	 *
	 * @param age the age of this users
	 */
	@Override
	public void setAge(String age) {
		model.setAge(age);
	}

	/**
	 * Sets the dob of this users.
	 *
	 * @param dob the dob of this users
	 */
	@Override
	public void setDob(Date dob) {
		model.setDob(dob);
	}

	/**
	 * Sets the email of this users.
	 *
	 * @param email the email of this users
	 */
	@Override
	public void setEmail(String email) {
		model.setEmail(email);
	}

	/**
	 * Sets the firstname of this users.
	 *
	 * @param firstname the firstname of this users
	 */
	@Override
	public void setFirstname(String firstname) {
		model.setFirstname(firstname);
	}

	/**
	 * Sets the gender of this users.
	 *
	 * @param gender the gender of this users
	 */
	@Override
	public void setGender(String gender) {
		model.setGender(gender);
	}

	/**
	 * Sets the hobbie of this users.
	 *
	 * @param hobbie the hobbie of this users
	 */
	@Override
	public void setHobbie(String hobbie) {
		model.setHobbie(hobbie);
	}

	/**
	 * Sets the ID of this users.
	 *
	 * @param id the ID of this users
	 */
	@Override
	public void setId(long id) {
		model.setId(id);
	}

	/**
	 * Sets the imagename of this users.
	 *
	 * @param imagename the imagename of this users
	 */
	@Override
	public void setImagename(String imagename) {
		model.setImagename(imagename);
	}

	/**
	 * Sets the imageupload of this users.
	 *
	 * @param imageupload the imageupload of this users
	 */
	@Override
	public void setImageupload(Blob imageupload) {
		model.setImageupload(imageupload);
	}

	/**
	 * Sets the lastname of this users.
	 *
	 * @param lastname the lastname of this users
	 */
	@Override
	public void setLastname(String lastname) {
		model.setLastname(lastname);
	}

	/**
	 * Sets the mobileno of this users.
	 *
	 * @param mobileno the mobileno of this users
	 */
	@Override
	public void setMobileno(String mobileno) {
		model.setMobileno(mobileno);
	}

	/**
	 * Sets the password of this users.
	 *
	 * @param password the password of this users
	 */
	@Override
	public void setPassword(String password) {
		model.setPassword(password);
	}

	/**
	 * Sets the primary key of this users.
	 *
	 * @param primaryKey the primary key of this users
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the uuid of this users.
	 *
	 * @param uuid the uuid of this users
	 */
	@Override
	public void setUuid(String uuid) {
		model.setUuid(uuid);
	}

	@Override
	protected UsersWrapper wrap(Users users) {
		return new UsersWrapper(users);
	}

}