/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package mainbuilder.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

import mainbuilder.model.Users;

/**
 * The cache model class for representing Users in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class UsersCacheModel implements CacheModel<Users>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof UsersCacheModel)) {
			return false;
		}

		UsersCacheModel usersCacheModel = (UsersCacheModel)object;

		if (id == usersCacheModel.id) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, id);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", id=");
		sb.append(id);
		sb.append(", firstname=");
		sb.append(firstname);
		sb.append(", lastname=");
		sb.append(lastname);
		sb.append(", email=");
		sb.append(email);
		sb.append(", mobileno=");
		sb.append(mobileno);
		sb.append(", dob=");
		sb.append(dob);
		sb.append(", gender=");
		sb.append(gender);
		sb.append(", hobbie=");
		sb.append(hobbie);
		sb.append(", age=");
		sb.append(age);
		sb.append(", imagename=");
		sb.append(imagename);
		sb.append(", password=");
		sb.append(password);
		sb.append(", address=");
		sb.append(address);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Users toEntityModel() {
		UsersImpl usersImpl = new UsersImpl();

		if (uuid == null) {
			usersImpl.setUuid("");
		}
		else {
			usersImpl.setUuid(uuid);
		}

		usersImpl.setId(id);

		if (firstname == null) {
			usersImpl.setFirstname("");
		}
		else {
			usersImpl.setFirstname(firstname);
		}

		if (lastname == null) {
			usersImpl.setLastname("");
		}
		else {
			usersImpl.setLastname(lastname);
		}

		if (email == null) {
			usersImpl.setEmail("");
		}
		else {
			usersImpl.setEmail(email);
		}

		if (mobileno == null) {
			usersImpl.setMobileno("");
		}
		else {
			usersImpl.setMobileno(mobileno);
		}

		if (dob == Long.MIN_VALUE) {
			usersImpl.setDob(null);
		}
		else {
			usersImpl.setDob(new Date(dob));
		}

		if (gender == null) {
			usersImpl.setGender("");
		}
		else {
			usersImpl.setGender(gender);
		}

		if (hobbie == null) {
			usersImpl.setHobbie("");
		}
		else {
			usersImpl.setHobbie(hobbie);
		}

		if (age == null) {
			usersImpl.setAge("");
		}
		else {
			usersImpl.setAge(age);
		}

		if (imagename == null) {
			usersImpl.setImagename("");
		}
		else {
			usersImpl.setImagename(imagename);
		}

		if (password == null) {
			usersImpl.setPassword("");
		}
		else {
			usersImpl.setPassword(password);
		}

		if (address == null) {
			usersImpl.setAddress("");
		}
		else {
			usersImpl.setAddress(address);
		}

		usersImpl.resetOriginalValues();

		return usersImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		id = objectInput.readLong();
		firstname = objectInput.readUTF();
		lastname = objectInput.readUTF();
		email = objectInput.readUTF();
		mobileno = objectInput.readUTF();
		dob = objectInput.readLong();
		gender = objectInput.readUTF();
		hobbie = objectInput.readUTF();
		age = objectInput.readUTF();
		imagename = objectInput.readUTF();
		password = objectInput.readUTF();
		address = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(id);

		if (firstname == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(firstname);
		}

		if (lastname == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(lastname);
		}

		if (email == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (mobileno == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(mobileno);
		}

		objectOutput.writeLong(dob);

		if (gender == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(gender);
		}

		if (hobbie == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(hobbie);
		}

		if (age == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(age);
		}

		if (imagename == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(imagename);
		}

		if (password == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(password);
		}

		if (address == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(address);
		}
	}

	public String uuid;
	public long id;
	public String firstname;
	public String lastname;
	public String email;
	public String mobileno;
	public long dob;
	public String gender;
	public String hobbie;
	public String age;
	public String imagename;
	public String password;
	public String address;

}