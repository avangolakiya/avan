create index IX_57556797 on Lr_Users (email[$COLUMN_LENGTH:75$]);
create index IX_B3CE25FF on Lr_Users (uuid_[$COLUMN_LENGTH:75$]);