create table Lr_Users (
	uuid_ VARCHAR(75) null,
	id_ LONG not null primary key,
	firstname VARCHAR(75) null,
	lastname VARCHAR(75) null,
	email VARCHAR(75) null,
	mobileno VARCHAR(75) null,
	dob DATE null,
	gender VARCHAR(75) null,
	hobbie VARCHAR(75) null,
	age VARCHAR(75) null,
	imagename VARCHAR(75) null,
	imageupload BLOB,
	password_ VARCHAR(75) null,
	address VARCHAR(75) null
);