/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package student.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link TodoService}.
 *
 * @author Brian Wing Shun Chan
 * @see TodoService
 * @generated
 */
public class TodoServiceWrapper
	implements ServiceWrapper<TodoService>, TodoService {

	public TodoServiceWrapper(TodoService todoService) {
		_todoService = todoService;
	}

	@Override
	public student.model.Todo addTodo(
		long id, String title, String discription) {

		return _todoService.addTodo(id, title, discription);
	}

	@Override
	public void deletTodoByid(long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		_todoService.deletTodoByid(id);
	}

	@Override
	public java.util.List<student.model.Todo> getAllTodo(int start, int end) {
		return _todoService.getAllTodo(start, end);
	}

	@Override
	public int getCount() {
		return _todoService.getCount();
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _todoService.getOSGiServiceIdentifier();
	}

	@Override
	public student.model.Todo getTodoByid(long id)
		throws com.liferay.portal.kernel.exception.PortalException {

		return _todoService.getTodoByid(id);
	}

	@Override
	public TodoService getWrappedService() {
		return _todoService;
	}

	@Override
	public void setWrappedService(TodoService todoService) {
		_todoService = todoService;
	}

	private TodoService _todoService;

}