/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package student.service.impl;

import com.liferay.portal.aop.AopService;
import com.liferay.portal.kernel.exception.PortalException;

import java.util.ArrayList;
import java.util.List;

import org.osgi.service.component.annotations.Component;

import student.model.Student;
import student.service.StudentLocalService;
import student.service.base.StudentServiceBaseImpl;

/**
 * @author Brian Wing Shun Chan
 */
@Component(
	property = {
		"json.web.service.context.name=lf",
		"json.web.service.context.path=Student"
	},
	service = AopService.class
)
public class StudentServiceImpl extends StudentServiceBaseImpl {
	
	
	public Student addStudent(long id,String name,String rollno,String subject) {
			
			return studentLocalService.addStudent(id,name,rollno,subject);	
			
		}
	
	public int getCount() {
		
		return studentLocalService.getStudentsCount();
	}
	
	public List<Student> getAllStudent(int start,int end){ 
		
		List<Student> student = new ArrayList<Student>();
		
		student = studentLocalService.getStudents(start, end);
		
		return student;
		
	}
	
	public Student getStudentByid(long id) throws PortalException{ 
		
		return studentLocalService.getStudent(id);
		
	}
	
public void deletStudentByid(long id) throws PortalException{ 
		
	studentLocalService.deleteStudent(id);
		
	}
	
}