create table lf_Student (
	uuid_ VARCHAR(75) null,
	studentid LONG not null primary key,
	createDate DATE null,
	modifiedDate DATE null,
	name VARCHAR(75) null,
	rollno VARCHAR(75) null,
	subject VARCHAR(75) null
);

create table lf_Todo (
	todoid LONG not null primary key,
	createDate DATE null,
	modifiedDate DATE null,
	title VARCHAR(75) null,
	discription VARCHAR(75) null
);